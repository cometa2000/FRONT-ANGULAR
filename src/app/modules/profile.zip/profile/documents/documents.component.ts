import { Component, OnInit } from '@angular/core';
import { ProfileService } from '../service/profile.service';

@Component({
  selector: 'app-documents',
  templateUrl: './documents.component.html',
})
export class DocumentsComponent implements OnInit {
  
  documentos: any[] = [];
  carpetas: any[] = [];
  archivos: any[] = [];
  isLoading: boolean = false;
  searchTerm: string = '';

  constructor(
    private profileService: ProfileService
  ) {}

  ngOnInit(): void {
    this.loadDocumentos();
  }

  /**
   * Cargar los documentos del usuario
   */
  loadDocumentos(): void {
    this.isLoading = true;
    
    this.profileService.getUserDocumentos(this.searchTerm).subscribe({
      next: (response) => {
        console.log('📁 Documentos cargados:', response);
        if (response.message === 200) {
          this.documentos = response.documentos || [];
          this.carpetas = response.carpetas || [];
          this.archivos = response.archivos || [];
        }
        this.isLoading = false;
      },
      error: (error) => {
        console.error('❌ Error al cargar documentos:', error);
        this.isLoading = false;
      }
    });
  }

  /**
   * Buscar documentos
   */
  onSearch(event: any): void {
    this.searchTerm = event.target.value;
    this.loadDocumentos();
  }

  /**
   * Descargar archivo
   */
  downloadFile(documento: any): void {
    if (documento.file_url) {
      window.open(documento.file_url, '_blank');
    }
  }

  /**
   * Ver archivo en nueva pestaña
   */
  viewFile(documento: any): void {
    if (documento.file_url) {
      window.open(documento.file_url, '_blank');
    }
  }

  /**
   * Obtener el icono apropiado para el documento
   */
  getDocumentIcon(documento: any): string {
    if (documento.icon) {
      return documento.icon;
    }
    
    if (documento.type === 'folder') {
      return './assets/media/svg/files/folder-document.svg';
    }
    
    return './assets/media/svg/files/blank.svg';
  }
}